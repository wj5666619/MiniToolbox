# Tools website‌ / 工具站
[English](#english) | [中文](#chinese)

---

<a id="chinese"></a>
![软件界面截图](pic.png)
### 项目简介
一个包含各种工具的网站，所有工具在浏览器本地运行不上传服务器。本项目界面、代码由人工智能助手辅助生成，由开发者手动调试、整合、优化并开源发布。


### 使用方法
访问[工具站](https://e-cny.github.io/)、[哔哩哔哩小玩具](https://www.bilibili.com/toy/3/index.html)或克隆本仓库后双击index.html离线使用

[视频演示](https://www.bilibili.com/video/BV1Ed4G6qEau)

---

<a id="english"></a>
### Project Introduction
A website containing various tools, all tools run locally in the browser without uploading to the server.GUI and code of this project are assisted by artificial intelligence assistant, manually debugged, integrated, optimized and open-sourced by the developer.

### Usage
Visit [Tools website](https://e-cny.github.io/),[bilibili Toy](https://www.bilibili.com/toy/3/index.html) or clone this repository and double-click index.html to use offline

[Video Demonstration](https://www.bilibili.com/video/BV1Ed4G6qEau)
