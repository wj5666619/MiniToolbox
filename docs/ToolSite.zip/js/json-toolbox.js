(function () {
  'use strict';

  // ================= 0. 全局工具函数 =================
  function getEl(id) { return document.getElementById(id); }
  function escapeHtml(str) {
    if (str === undefined || str === null) return '';
    return String(str).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  var toastEl = getEl('toast');
  var toastTimer = null;
  window.showToast = function (msg) {
    if (!toastEl) return;
    toastEl.textContent = msg;
    toastEl.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { toastEl.classList.remove('show'); }, 1600);
  };

  window.copyText = function (id) {
    var el = getEl(id);
    if (!el || !el.value) return showToast('没有可复制的内容');
    
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(el.value).then(function () {
        showToast('✅ 已复制到剪贴板');
      }).catch(function () {
        fallbackCopy(el);
      });
    } else {
      fallbackCopy(el);
    }
    
    function fallbackCopy(el) {
      el.select();
      document.execCommand('copy');
      showToast('✅ 已复制到剪贴板');
    }
  };

  window.clearInput = function (id) {
    var el = getEl(id);
    if (el) el.value = '';
    showToast('已清空');
  };

  window.downloadText = function (id, filename) {
    var el = getEl(id);
    if (!el || !el.value) return showToast('没有可下载的内容');
    var blob = new Blob([el.value], { type: 'text/plain;charset=utf-8' });
    var url = URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url; a.download = filename || 'output.txt';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    showToast('已下载文件');
  };

  // ================= 1. Tab 切换 =================
  var navBtns = document.querySelectorAll('.jt-nav-btn');
  var panels = document.querySelectorAll('.jt-panel');

  navBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      navBtns.forEach(function (b) { b.classList.remove('active'); });
      panels.forEach(function (p) { p.classList.remove('active'); });
      btn.classList.add('active');
      getEl(btn.dataset.target).classList.add('active');
    });
  });

  // ================= 2. JSON 格式化与校验 =================
  window.jsonFormat = function (space) {
    var input = getEl('json-input').value.trim();
    var errorMsg = getEl('json-error-msg');
    errorMsg.textContent = '';
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      getEl('json-output').value = JSON.stringify(obj, null, space);
    } catch (e) {
      errorMsg.textContent = '❌ 错误: ' + e.message;
    }
  };

  window.jsonMinify = function () {
    var input = getEl('json-input').value.trim();
    var errorMsg = getEl('json-error-msg');
    errorMsg.textContent = '';
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      getEl('json-output').value = JSON.stringify(obj);
    } catch (e) {
      errorMsg.textContent = '❌ 错误: ' + e.message;
    }
  };

  // 新增：按键名排序
  window.jsonSortKeys = function () {
    var input = getEl('json-input').value.trim();
    var errorMsg = getEl('json-error-msg');
    errorMsg.textContent = '';
    if (!input) return;
    
    function sortObject(obj) {
      if (obj === null || typeof obj !== 'object') return obj;
      if (Array.isArray(obj)) return obj.map(sortObject);
      
      var sortedObj = {};
      Object.keys(obj).sort().forEach(function (key) {
        sortedObj[key] = sortObject(obj[key]);
      });
      return sortedObj;
    }

    try {
      var parsed = JSON.parse(input);
      var sorted = sortObject(parsed);
      getEl('json-output').value = JSON.stringify(sorted, null, 2);
      showToast('键名已按字母排序');
    } catch (e) {
      errorMsg.textContent = '❌ 错误: ' + e.message;
    }
  };

  window.jsonEscape = function () {
    var input = getEl('json-input').value;
    getEl('json-output').value = JSON.stringify(input);
  };

  window.jsonUnescape = function () {
    var input = getEl('json-input').value;
    try {
      var obj = JSON.parse(input);
      if (typeof obj === 'string') getEl('json-output').value = obj;
      else getEl('json-output').value = JSON.stringify(obj, null, 2);
    } catch (e) {
      getEl('json-error-msg').textContent = '❌ 去转义失败，不是有效的 JSON 字符串';
    }
  };

  // ================= 3. YAML <-> JSON =================
  window.yamlToJson = function () {
    var input = getEl('yaml-input').value.trim();
    if (!input) return;
    try {
      var obj = jsyaml.load(input);
      getEl('yaml-output').value = JSON.stringify(obj, null, 2);
      showToast('YAML 转 JSON 成功');
    } catch (e) {
      getEl('yaml-output').value = '❌ YAML 解析错误: ' + e.message;
    }
  };

  window.jsonToYaml = function () {
    var input = getEl('yaml-input').value.trim();
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      getEl('yaml-output').value = jsyaml.dump(obj);
      showToast('JSON 转 YAML 成功');
    } catch (e) {
      getEl('yaml-output').value = '❌ JSON 解析错误: ' + e.message;
    }
  };

  // ================= 4. XML <-> JSON =================
  window.xmlToJson = function () {
    var input = getEl('xml-input').value.trim();
    if (!input) return;
    try {
      var parser = new DOMParser();
      var xmlDoc = parser.parseFromString(input, 'text/xml');
      var obj = xmlToJsonNode(xmlDoc.documentElement);
      getEl('xml-output').value = JSON.stringify(obj, null, 2);
      showToast('XML 转 JSON 成功');
    } catch (e) {
      getEl('xml-output').value = '❌ XML 解析错误: ' + e.message;
    }
  };

  function xmlToJsonNode(node) {
    if (node.nodeType === 3) return node.nodeValue.trim();
    var obj = {};
    if (node.attributes && node.attributes.length > 0) {
      obj['@attributes'] = {};
      for (var i = 0; i < node.attributes.length; i++) {
        var attr = node.attributes[i];
        obj['@attributes'][attr.nodeName] = attr.nodeValue;
      }
    }
    if (node.hasChildNodes()) {
      for (var i = 0; i < node.childNodes.length; i++) {
        var child = node.childNodes[i];
        if (child.nodeType === 3 && child.nodeValue.trim() === '') continue;
        var nodeName = child.nodeName;
        var childObj = xmlToJsonNode(child);
        if (nodeName === '#text') nodeName = '#text';
        if (obj[nodeName] !== undefined) {
          if (!Array.isArray(obj[nodeName])) obj[nodeName] = [obj[nodeName]];
          obj[nodeName].push(childObj);
        } else {
          obj[nodeName] = childObj;
        }
      }
    }
    return Object.keys(obj).length === 0 ? '' : obj;
  }

  window.jsonToXml = function () {
    var input = getEl('xml-input').value.trim();
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      var xmlStr = '<?xml version="1.0" encoding="UTF-8"?>\n' + jsonToXmlNode('root', obj);
      getEl('xml-output').value = xmlStr;
      showToast('JSON 转 XML 成功');
    } catch (e) {
      getEl('xml-output').value = '❌ JSON 解析错误: ' + e.message;
    }
  };

  function jsonToXmlNode(tag, data) {
    var xml = '';
    if (Array.isArray(data)) {
      data.forEach(function (item) { xml += jsonToXmlNode(tag, item); });
    } else if (typeof data === 'object' && data !== null) {
      xml += '<' + tag + '>';
      for (var key in data) {
        if (key === '@attributes') {
          for (var attr in data[key]) {
            xml = xml.replace('<' + tag, '<' + tag + ' ' + attr + '="' + data[key][attr] + '"');
          }
        } else {
          xml += jsonToXmlNode(key, data[key]);
        }
      }
      xml += '</' + tag + '>';
    } else {
      xml += '<' + tag + '>' + String(data) + '</' + tag + '>';
    }
    return xml;
  }

  // ================= 5. TOML <-> JSON =================
  function nativeTomlParse(str) {
    var result = {};
    var current = result;
    var lines = str.split(/\r?\n/);
    var i = 0;
    
    while (i < lines.length) {
      var line = lines[i].trim();
      i++;
      
      if (!line || line.startsWith('#')) continue;
      
      if (line.startsWith('[') && line.endsWith(']')) {
        var tableName = line.slice(1, -1).trim();
        if (tableName.startsWith('[') && tableName.endsWith(']')) {
          tableName = tableName.slice(1, -1).trim();
        }
        var parts = tableName.split('.').map(function(p) { return p.trim().replace(/^["']|["']$/g, ''); });
        current = result;
        for (var p of parts) {
          if (!current[p]) current[p] = {};
          current = current[p];
        }
        continue;
      }
      
      var eqIdx = line.indexOf('=');
      if (eqIdx === -1) continue;
      
      var key = line.slice(0, eqIdx).trim().replace(/^["']|["']$/g, '');
      var valStr = line.slice(eqIdx + 1).trim();
      
      if (valStr.startsWith('[') && !valStr.endsWith(']')) {
        while (i < lines.length) {
          var nextLine = lines[i].trim();
          valStr += ' ' + nextLine;
          i++;
          if (nextLine.endsWith(']')) break;
        }
      }
      
      var hashIdx = valStr.indexOf('#');
      if (hashIdx !== -1 && !valStr.includes('"') && !valStr.includes("'")) {
        valStr = valStr.slice(0, hashIdx).trim();
      }
      
      current[key] = parseTomlValue(valStr);
    }
    return result;
  }

  function parseTomlValue(valStr) {
    if (valStr.startsWith('"') && valStr.endsWith('"')) {
      return valStr.slice(1, -1).replace(/\\"/g, '"').replace(/\\n/g, '\n').replace(/\\t/g, '\t');
    }
    if (valStr.startsWith("'") && valStr.endsWith("'")) {
      return valStr.slice(1, -1);
    }
    if (valStr === 'true') return true;
    if (valStr === 'false') return false;
    
    if (valStr.startsWith('[') && valStr.endsWith(']')) {
      var arrStr = valStr.slice(1, -1).trim();
      if (!arrStr) return [];
      return arrStr.split(',').map(function(v) { return parseTomlValue(v.trim()); });
    }
    
    var num = Number(valStr);
    if (!isNaN(num) && valStr !== '') return num;
    
    if (/^\d{4}-\d{2}-\d{2}/.test(valStr)) {
      return new Date(valStr);
    }
    return valStr;
  }

  function nativeTomlStringify(obj, prefix) {
    prefix = prefix || '';
    var lines = [];
    var tables = [];
    
    for (var key in obj) {
      var val = obj[key];
      if (val === null || val === undefined) continue;
      
      if (typeof val === 'object' && !Array.isArray(val) && !(val instanceof Date)) {
        tables.push({ key: key, val: val });
      } else {
        lines.push(key + ' = ' + stringifyTomlValue(val));
      }
    }
    
    var resultStr = lines.join('\n');
    
    for (var t of tables) {
      var tableName = prefix ? prefix + '.' + t.key : t.key;
      if (resultStr.length > 0 && !resultStr.endsWith('\n')) {
        resultStr += '\n';
      }
      resultStr += '\n[' + tableName + ']\n';
      var subStr = nativeTomlStringify(t.val, tableName);
      resultStr += subStr;
    }
    
    return resultStr;
  }

  function stringifyTomlValue(val) {
    if (typeof val === 'string') {
      return '"' + val.replace(/\\/g, '\\\\').replace(/"/g, '\\"').replace(/\n/g, '\\n') + '"';
    }
    if (val instanceof Date) {
      return val.toISOString();
    }
    if (Array.isArray(val)) {
      return '[' + val.map(stringifyTomlValue).join(', ') + ']';
    }
    return String(val);
  }

  window.tomlToJson = function () {
    var input = getEl('toml-input').value.trim();
    if (!input) return;
    try {
      var obj = nativeTomlParse(input);
      getEl('toml-output').value = JSON.stringify(obj, null, 2);
      showToast('TOML 转 JSON 成功');
    } catch (e) {
      getEl('toml-output').value = '❌ TOML 解析错误: ' + e.message;
    }
  };

  window.jsonToToml = function () {
    var activeTab = document.querySelector('.jt-panel.active').id;
    var isJsonPanel = activeTab === 'panel-json';
    
    var input = isJsonPanel ? getEl('json-input').value.trim() : getEl('toml-input').value.trim();
    if (!input) return;
    
    try {
      var obj = JSON.parse(input);
      var outStr = nativeTomlStringify(obj);
      if (isJsonPanel) {
        getEl('json-output').value = outStr;
      } else {
        getEl('toml-output').value = outStr;
      }
      showToast('JSON 转 TOML 成功');
    } catch (e) {
      var err = '❌ JSON 解析错误: ' + e.message;
      if (isJsonPanel) {
        getEl('json-output').value = err;
      } else {
        getEl('toml-output').value = err;
      }
    }
  };

  // ================= 6. JSON <-> CSV (新增) =================
  window.jsonToCsv = function () {
    var input = getEl('csv-input').value.trim();
    if (!input) return;
    try {
      var data = JSON.parse(input);
      if (!Array.isArray(data)) {
        throw new Error('JSON 根节点必须是数组 (Array) 才能转为 CSV');
      }
      if (data.length === 0) return showToast('数组为空');
      
      // 提取所有键去重
      var headers = new Set();
      data.forEach(function (obj) {
        if (typeof obj === 'object' && obj !== null) {
          Object.keys(obj).forEach(function (k) { headers.add(k); });
        }
      });
      var headerArr = Array.from(headers);
      
      // 辅助函数：转义 CSV 值
      function escapeCsv(val) {
        if (val === null || val === undefined) return '';
        var str = typeof val === 'object' ? JSON.stringify(val) : String(val);
        if (str.includes('"') || str.includes(',') || str.includes('\n')) {
          return '"' + str.replace(/"/g, '""') + '"';
        }
        return str;
      }

      var csvLines = [];
      csvLines.push(headerArr.map(escapeCsv).join(','));
      
      data.forEach(function (obj) {
        var row = headerArr.map(function (key) {
          return escapeCsv(obj[key]);
        });
        csvLines.push(row.join(','));
      });

      getEl('csv-output').value = csvLines.join('\n');
      showToast('JSON 转 CSV 成功');
    } catch (e) {
      getEl('csv-output').value = '❌ 转换失败: ' + e.message;
    }
  };

  window.csvToJson = function () {
    var input = getEl('csv-input').value.trim();
    if (!input) return;
    try {
      // 简单的 CSV 解析（支持引号转义）
      var lines = input.split(/\r?\n/).filter(function(line) { return line.trim() !== ''; });
      if (lines.length < 2) throw new Error('CSV 至少需要包含表头和一行数据');
      
      function parseCsvLine(line) {
        var result = [];
        var current = '';
        var inQuotes = false;
        for (var i = 0; i < line.length; i++) {
          var char = line[i];
          if (char === '"') {
            if (inQuotes && line[i+1] === '"') { current += '"'; i++; }
            else { inQuotes = !inQuotes; }
          } else if (char === ',' && !inQuotes) {
            result.push(current);
            current = '';
          } else {
            current += char;
          }
        }
        result.push(current);
        return result;
      }

      var headers = parseCsvLine(lines[0]);
      var result = [];
      
      for (var i = 1; i < lines.length; i++) {
        var vals = parseCsvLine(lines[i]);
        var obj = {};
        for (var j = 0; j < headers.length; j++) {
          var val = vals[j] || '';
          // 尝试智能转换数字
          if (val !== '' && !isNaN(val) && val.indexOf(',') === -1) {
            obj[headers[j]] = Number(val);
          } else if (val.toLowerCase() === 'true') {
            obj[headers[j]] = true;
          } else if (val.toLowerCase() === 'false') {
            obj[headers[j]] = false;
          } else {
            obj[headers[j]] = val;
          }
        }
        result.push(obj);
      }

      getEl('csv-output').value = JSON.stringify(result, null, 2);
      showToast('CSV 转 JSON 成功');
    } catch (e) {
      getEl('csv-output').value = '❌ 转换失败: ' + e.message;
    }
  };

  // ================= 7. JSON 转 SQL (新增) =================
  window.jsonToSql = function () {
    var input = getEl('sql-input').value.trim();
    var tableName = getEl('sql-table-name').value.trim() || 'my_table';
    var dialect = getEl('sql-dialect').value;
    
    if (!input) return;
    try {
      var data = JSON.parse(input);
      if (!Array.isArray(data)) throw new Error('需要数组格式的 JSON 才能生成 SQL');
      if (data.length === 0) return showToast('数组为空');

      var headers = Object.keys(data[0]);
      
      // 辅助函数：转义 SQL 值
      function escapeSql(val) {
        if (val === null || val === undefined) return 'NULL';
        if (typeof val === 'number' || typeof val === 'boolean') return val;
        var str = String(val);
        // 转义单引号
        return "'" + str.replace(/'/g, "''") + "'";
      }

      // 生成 INSERT 语句
      var columns = headers.map(function(h) {
        return dialect === 'mysql' ? '`' + h + '`' : '"' + h + '"';
      }).join(', ');

      var sql = 'INSERT INTO ' + tableName + ' (' + columns + ') VALUES\n';
      
      var rows = data.map(function (obj) {
        var vals = headers.map(function (h) { return escapeSql(obj[h]); });
        return '(' + vals.join(', ') + ')';
      });

      sql += rows.join(',\n') + ';\n';
      
      getEl('sql-output').value = sql;
      showToast('SQL INSERT 生成成功');
    } catch (e) {
      getEl('sql-output').value = '❌ 生成失败: ' + e.message;
    }
  };

  // ================= 8. BSON / Base64 =================
  window.jsonToBase64 = function () {
    var input = getEl('bson-input').value.trim();
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      var str = JSON.stringify(obj);
      var b64 = btoa(unescape(encodeURIComponent(str)));
      getEl('bson-output').value = b64;
      showToast('转 Base64 成功');
    } catch (e) {
      getEl('bson-output').value = '❌ JSON 解析错误: ' + e.message;
    }
  };

  window.base64ToJson = function () {
    var input = getEl('bson-input').value.trim();
    if (!input) return;
    try {
      var str = decodeURIComponent(escape(atob(input)));
      var obj = JSON.parse(str);
      getEl('bson-output').value = JSON.stringify(obj, null, 2);
      showToast('转 JSON 成功');
    } catch (e) {
      getEl('bson-output').value = '❌ Base64 解析错误: ' + e.message;
    }
  };

  // ================= 9. JSONPath =================
  window.runJsonPath = function () {
    var jsonStr = getEl('jsonpath-input').value.trim();
    var path = getEl('jsonpath-query').value.trim();
    if (!jsonStr || !path) return;
    try {
      var obj = JSON.parse(jsonStr);
      var result = jsonpath.query(obj, path);
      getEl('jsonpath-output').value = JSON.stringify(result, null, 2);
      showToast('查询成功');
    } catch (e) {
      getEl('jsonpath-output').value = '❌ 执行错误: ' + e.message;
    }
  };

  // ================= 10. JMESPath =================
  window.runJmesPath = function () {
    var jsonStr = getEl('jmespath-input').value.trim();
    var path = getEl('jmespath-query').value.trim();
    if (!jsonStr || !path) return;
    try {
      var obj = JSON.parse(jsonStr);
      var result = jmespath.search(obj, path);
      getEl('jmespath-output').value = JSON.stringify(result, null, 2);
      showToast('查询成功');
    } catch (e) {
      getEl('jmespath-output').value = '❌ 执行错误: ' + e.message;
    }
  };

  // ================= 11. JSON Pointer =================
  window.runJsonPointer = function () {
    var jsonStr = getEl('pointer-input').value.trim();
    var pointer = getEl('pointer-query').value.trim();
    if (!jsonStr || !pointer) return;
    try {
      var obj = JSON.parse(jsonStr);
      if (pointer === '') {
        getEl('pointer-output').value = JSON.stringify(obj, null, 2);
        return;
      }
      var parts = pointer.split('/').slice(1);
      var current = obj;
      for (var i = 0; i < parts.length; i++) {
        var part = decodeURIComponent(parts[i].replace(/~1/g, '/').replace(/~0/g, '~'));
        current = current[part];
        if (current === undefined) throw new Error('路径不存在: ' + part);
      }
      getEl('pointer-output').value = JSON.stringify(current, null, 2);
      showToast('定位成功');
    } catch (e) {
      getEl('pointer-output').value = '❌ 定位失败: ' + e.message;
    }
  };

  // ================= 12. JSON Schema =================
  window.validateSchema = function () {
    var jsonStr = getEl('schema-json').value.trim();
    var schemaStr = getEl('schema-input').value.trim();
    var outEl = getEl('schema-output');
    if (!jsonStr || !schemaStr) return;
    
    outEl.innerHTML = '正在校验...';
    try {
      var data = JSON.parse(jsonStr);
      var schema = JSON.parse(schemaStr);
      var ajv = new Ajv();
      var validate = ajv.compile(schema);
      var valid = validate(data);
      
      if (valid) {
        outEl.innerHTML = '<span style="color:#7ba05b; font-weight:bold;">✅ 校验通过：数据符合 Schema 规范。</span>';
        showToast('校验通过');
      } else {
        outEl.innerHTML = '<span style="color:#a8452a; font-weight:bold;">❌ 校验失败：</span><br>' + 
          validate.errors.map(function(err) { 
            return '- 路径 <b>' + err.instancePath + '</b>: ' + err.message; 
          }).join('<br>');
        showToast('校验失败');
      }
    } catch (e) {
      outEl.innerHTML = '<span style="color:#a8452a;">❌ 处理失败: ' + e.message + '</span>';
    }
  };

  // ================= 13. JSON 结构 Diff =================
  window.runJsonDiff = function () {
    var aStr = getEl('diff-input-a').value.trim();
    var bStr = getEl('diff-input-b').value.trim();
    var outEl = getEl('diff-output');
    if (!aStr || !bStr) return;
    try {
      var objA = JSON.parse(aStr);
      var objB = JSON.parse(bStr);
      outEl.innerHTML = '';
      var diffCount = 0;
      
      function renderDiff(a, b, path) {
        if (a === b) return '';
        if (typeof a !== typeof b || a === null || b === null || typeof a !== 'object') {
          diffCount++;
          if (a === undefined) return '<div>➕ <b>' + path + '</b>: <span class="diff-add">' + JSON.stringify(b) + '</span></div>';
          if (b === undefined) return '<div>➖ <b>' + path + '</b>: <span class="diff-remove">' + JSON.stringify(a) + '</span></div>';
          return '<div>🔄 <b>' + path + '</b>: <span class="diff-remove">' + JSON.stringify(a) + '</span> → <span class="diff-add">' + JSON.stringify(b) + '</span></div>';
        }
        if (Array.isArray(a) && Array.isArray(b)) {
          var res = '';
          var maxLen = Math.max(a.length, b.length);
          for (var i = 0; i < maxLen; i++) res += renderDiff(a[i], b[i], path + '[' + i + ']');
          return res;
        }
        var html = '';
        var keys = new Set([...Object.keys(a), ...Object.keys(b)]);
        keys.forEach(function (k) {
          html += renderDiff(a[k], b[k], path ? path + '.' + k : k);
        });
        return html;
      }

      var diffHtml = renderDiff(objA, objB, '');
      if (diffHtml) {
        outEl.innerHTML = '<div style="margin-bottom:10px; color:#6b5d47; font-weight:bold;">共发现 ' + diffCount + ' 处差异：</div>' + diffHtml;
        showToast('对比完成，发现差异');
      } else {
        outEl.innerHTML = '<span style="color:#7ba05b;">✅ 两个 JSON 完全一致。</span>';
        showToast('完全一致');
      }
    } catch (e) {
      outEl.innerHTML = '<span style="color:#a8452a;">❌ 解析错误: ' + e.message + '</span>';
    }
  };

  // ================= 14. 文本 Diff (支持行号) =================
  function initLineNumbers(textareaId, linesId) {
    var ta = document.getElementById(textareaId);
    var linesEl = document.getElementById(linesId);
    if(!ta || !linesEl) return;
    
    function update() {
      var linesCount = ta.value.split('\n').length;
      var arr = [];
      for(var i = 1; i <= linesCount; i++) arr.push(i);
      linesEl.innerHTML = arr.join('<br>');
      linesEl.scrollTop = ta.scrollTop;
    }
    ta.addEventListener('input', update);
    ta.addEventListener('scroll', function() { linesEl.scrollTop = ta.scrollTop; });
    update();
  }
  
  setTimeout(function(){
    initLineNumbers('text-diff-old', 'lines-old');
    initLineNumbers('text-diff-new', 'lines-new');
  }, 100);

  window.runTextDiff = function () {
    var oldText = getEl('text-diff-old').value;
    var newText = getEl('text-diff-new').value;
    var outEl = getEl('text-diff-output');
    
    if (!oldText && !newText) return;

    if (!window.Diff && !window.jsdiff) {
      outEl.innerHTML = '<span style="color:#a8452a; padding: 12px; display: block;">❌ Diff 库未加载，请检查网络或 js/libs/diff.min.js</span>';
      return;
    }
    var diffLib = window.Diff || window.jsdiff;

    var ignoreCase = getEl('text-diff-ignore-case').checked;
    var ignoreSpace = getEl('text-diff-ignore-space').checked;

    var o = oldText.endsWith('\n') ? oldText : oldText + '\n';
    var n = newText.endsWith('\n') ? newText : newText + '\n';

    var diffLines = diffLib.diffLines(o, n, {
      ignoreCase: ignoreCase,
      ignoreWhitespace: ignoreSpace
    });

    var html = '';
    var oldLineNum = 1;
    var newLineNum = 1;
    var addCount = 0, delCount = 0;

    diffLines.forEach(function (part) {
      var lines = part.value.split('\n');
      if (lines[lines.length - 1] === '') lines.pop();

      var typeClass = part.added ? 'diff-line-add' : (part.removed ? 'diff-line-remove' : 'diff-line-neutral');
      var prefix = part.added ? '+' : (part.removed ? '-' : ' ');
      
      lines.forEach(function (line) {
        var oldNumStr = '';
        var newNumStr = '';
        
        if (part.added) {
            newNumStr = newLineNum++;
            addCount++;
        } else if (part.removed) {
            oldNumStr = oldLineNum++;
            delCount++;
        } else {
            oldNumStr = oldLineNum++;
            newNumStr = newLineNum++;
        }

        html += '<div class="diff-line ' + typeClass + '">' +
          '<div class="diff-line-num">' + oldNumStr + '</div>' +
          '<div class="diff-line-num">' + newNumStr + '</div>' +
          '<div class="diff-line-prefix">' + prefix + '</div>' +
          '<div class="diff-line-content">' + escapeHtml(line) + '</div>' +
          '</div>';
      });
    });

    var stats = '<div style="padding: 10px 16px; background: #f9f3e3; border-bottom: 1px solid #d5c7a8; font-size: 0.85rem; font-weight: bold; color: #6b5d47;">';
    stats += '新增: <span style="color:#166534;">+' + addCount + '</span> | ';
    stats += '删除: <span style="color:#991b1b;">-' + delCount + '</span>';
    stats += '</div>';

    if (addCount > 0 || delCount > 0) {
      outEl.innerHTML = stats + (html || '<p style="padding: 12px; margin: 0;">无差异</p>');
      showToast('对比完成');
    } else {
      outEl.innerHTML = '<p style="color:#7ba05b; padding: 12px; margin: 0;">✅ 两边文本完全一致。</p>';
      showToast('完全一致');
    }
  };

  window.clearTextDiff = function () {
    getEl('text-diff-old').value = '';
    getEl('text-diff-new').value = '';
    getEl('text-diff-output').innerHTML = '';
    getEl('lines-old').innerHTML = '1';
    getEl('lines-new').innerHTML = '1';
  };

  // ================= 15. JSON 树形视图 =================
  window.renderTree = function () {
    var input = getEl('tree-input').value.trim();
    var outEl = getEl('tree-output');
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      outEl.innerHTML = buildTree(obj, null);
      showToast('生成成功');
    } catch (e) {
      outEl.innerHTML = '<span style="color:#a8452a;">❌ JSON 解析错误: ' + e.message + '</span>';
    }
  };

  window.expandTree = function (expand) {
    var details = getEl('tree-output').querySelectorAll('details');
    for (var i = 0; i < details.length; i++) {
      details[i].open = expand;
    }
  };

  function buildTree(data, key) {
    var keyStr = key !== null ? '<span class="key">' + key + '</span>: ' : '';
    if (data === null) return '<div>' + keyStr + '<span class="null">null</span></div>';
    if (typeof data !== 'object') {
      var cls = typeof data === 'string' ? 'string' : (typeof data === 'number' ? 'number' : 'boolean');
      var val = typeof data === 'string' ? '"' + data + '"' : data;
      return '<div>' + keyStr + '<span class="' + cls + '">' + val + '</span></div>';
    }
    if (Array.isArray(data)) {
      var html = '<details open><summary>' + keyStr + 'Array(' + data.length + ')</summary><ul>';
      data.forEach(function (item, i) { html += '<li>' + buildTree(item, i) + '</li>'; });
      return html + '</ul></details>';
    }
    var keys = Object.keys(data);
    var html = '<details open><summary>' + keyStr + 'Object</summary><ul>';
    keys.forEach(function (k) { html += '<li>' + buildTree(data[k], k) + '</li>'; });
    return html + '</ul></details>';
  }

  // ================= 16. JSON 表单 =================
  window.generateForm = function () {
    var input = getEl('form-json').value.trim();
    var outEl = getEl('form-container');
    if (!input) return;
    try {
      var obj = JSON.parse(input);
      outEl.innerHTML = '';
      generateFormFields(obj, '', outEl);
      showToast('表单生成成功');
    } catch (e) {
      outEl.innerHTML = '<span style="color:#a8452a;">❌ JSON 解析错误: ' + e.message + '</span>';
    }
  };

  function generateFormFields(data, path, container) {
    if (typeof data !== 'object' || data === null) {
      var div = document.createElement('div');
      div.className = 'form-group';
      var label = document.createElement('label');
      label.textContent = path || 'Value';
      var input;
      if (typeof data === 'boolean') {
        input = document.createElement('select');
        input.innerHTML = '<option value="true"' + (data ? ' selected' : '') + '>true</option><option value="false"' + (!data ? ' selected' : '') + '>false</option>';
      } else if (typeof data === 'number') {
        input = document.createElement('input');
        input.type = 'number';
        input.value = data;
      } else {
        input = document.createElement('input');
        input.type = 'text';
        input.value = data;
      }
      input.dataset.path = path;
      div.appendChild(label);
      div.appendChild(input);
      container.appendChild(div);
      return;
    }
    if (Array.isArray(data)) {
      data.forEach(function (item, i) {
        generateFormFields(item, path + '[' + i + ']', container);
      });
      return;
    }
    for (var key in data) {
      generateFormFields(data[key], path ? path + '.' + key : key, container);
    }
  }

  window.formToJson = function () {
    var outEl = getEl('form-json');
    var container = getEl('form-container');
    var inputs = container.querySelectorAll('input, select');
    if (inputs.length === 0) return;

    var result = {};
    inputs.forEach(function (input) {
      var path = input.dataset.path;
      var val = input.value;
      if (input.type === 'number') val = Number(val);
      if (input.tagName === 'SELECT') val = val === 'true';
      
      var keys = path.replace(/\[(\d+)\]/g, '.$1').split('.');
      var current = result;
      for (var i = 0; i < keys.length - 1; i++) {
        var k = keys[i];
        if (!current[k]) {
          current[k] = isNaN(keys[i + 1]) ? {} : [];
        }
        current = current[k];
      }
      current[keys[keys.length - 1]] = val;
    });

    outEl.value = JSON.stringify(result, null, 2);
    showToast('已转为 JSON');
  };

  // ================= 17. JSON 转 TS 接口 =================
  window.generateTS = function () {
    var jsonInputEl = getEl('ts-json-input');
    var tsOutputEl = getEl('ts-code-output');
    var rootNameEl = getEl('ts-root-name');
    var styleSelectEl = getEl('ts-style');
    var optSemicolonEl = getEl('ts-semicolon');
    var optOptionalEl = getEl('ts-optional');

    var raw = jsonInputEl.value.trim();
    if (!raw) {
      tsOutputEl.value = '';
      return;
    }

    try {
      var parsed = JSON.parse(raw);
      
      var interfaces = [];
      var rootName = rootNameEl.value.trim() || 'RootObject';
      var useType = styleSelectEl.value === 'type';
      var useSemicolon = optSemicolonEl.checked;
      var useOptional = optOptionalEl.checked;

      // TS 保留字列表
      var RESERVED_WORDS = ['break', 'case', 'catch', 'class', 'const', 'continue', 'debugger', 'default', 'delete', 'do', 'else', 'enum', 'export', 'extends', 'false', 'finally', 'for', 'function', 'if', 'import', 'in', 'instanceof', 'new', 'null', 'return', 'super', 'switch', 'this', 'throw', 'true', 'try', 'typeof', 'var', 'void', 'while', 'with', 'as', 'implements', 'interface', 'let', 'package', 'private', 'protected', 'public', 'static', 'yield', 'any', 'boolean', 'constructor', 'declare', 'get', 'module', 'require', 'number', 'set', 'string', 'symbol', 'type', 'from', 'of'];

      function capitalizeFirstLetter(str) {
        return str.charAt(0).toUpperCase() + str.slice(1);
      }

      function cleanName(str) {
        var cleaned = str.replace(/[-_\s]+(.)?/g, function(match, chr) {
          return chr ? chr.toUpperCase() : '';
        });
        return capitalizeFirstLetter(cleaned);
      }

      function parseValue(val, name) {
        if (val === null) return 'any';
        if (Array.isArray(val)) {
          if (val.length === 0) return 'any[]';
          var types = new Set();
          val.forEach(function(item) {
            types.add(parseValue(item, name));
          });
          var typeStr = Array.from(types).join(' | ');
          if (types.size > 1) {
            return '(' + typeStr + ')[]';
          }
          return typeStr + '[]';
        }
        var type = typeof val;
        if (type === 'object') {
          return generateInterface(val, name);
        }
        return type;
      }

      function generateInterface(obj, name) {
        var interfaceName = cleanName(name) || 'RootObject';
        var existing = interfaces.find(function(i) { return i.name === interfaceName; });
        if (existing) return interfaceName;

        var lines = [];
        lines.push((useType ? 'export type ' : 'export interface ') + interfaceName + ' {');
        var keys = Object.keys(obj);
        
        keys.forEach(function(key) {
          var val = obj[key];
          var propName = key;
          
          // 处理非法属性名和保留字
          if (!/^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(propName) || RESERVED_WORDS.indexOf(propName) !== -1) {
            propName = "'" + propName + "'";
          }
          
          var isOptional = useOptional && (val === undefined || val === null);
          var typeStr = parseValue(val, interfaceName + '_' + key);
          
          lines.push('  ' + propName + (isOptional ? '?' : '') + ': ' + typeStr + (useSemicolon ? ';' : ''));
        });
        
        lines.push('}');
        
        interfaces.push({
          name: interfaceName,
          code: lines.join('\n')
        });
        return interfaceName;
      }

      var rootType = parseValue(parsed, rootName);

      if (rootType === cleanName(rootName)) {
        // 正常对象处理完毕
      } else if (rootType !== cleanName(rootName) && rootType !== cleanName(rootName) + '[]' && !rootType.startsWith('(')) {
        // 基础类型，直接返回
      } else {
         // 根节点是基础类型或数组
         tsOutputEl.value = 'export type ' + cleanName(rootName) + ' = ' + rootType + (useSemicolon ? ';' : '');
         return;
      }

      var result = [];
      for (var i = interfaces.length - 1; i >= 0; i--) {
        result.push(interfaces[i].code);
      }
      
      tsOutputEl.value = result.join('\n\n');
      showToast('TypeScript 接口生成成功');
    } catch (e) {
      tsOutputEl.value = '// 解析失败，请检查 JSON 格式是否正确。\n// ' + e.message;
    }
  };

  window.fillTSSample = function () {
    var sample = {
      "id": 1024,
      "name": "John Doe",
      "isActive": true,
      "roles": ["admin", "editor"],
      "class": "VIP", // 测试保留字
      "profile": {
        "age": 30,
        "address": {
          "city": "New York",
          "zip": "10001"
        }
      },
      "projects": [
        {
          "projectId": 1,
          "projectName": "Alpha",
          "stars": 120
        },
        {
          "projectId": 2,
          "projectName": "Beta",
          "stars": 350
        }
      ]
    };
    getEl('ts-json-input').value = JSON.stringify(sample, null, 2);
    window.generateTS();
  };

})();